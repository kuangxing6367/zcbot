IIPC Linux/amd64 编译产物  (zcbot v1.8.9-beta.1)
==================================================

包含：
  go_kernel/zcbot_kernel.exe               Go 内核（事件总线 / SQLite / 插件编排）
  rust_adapter/target/release/zcbot_adapter.exe   Rust 协议端（OneBot 11，正/反向 WS 双模式）

注意：文件名保留 .exe 是**有意为之**。framework/iipc/launcher.py 把产物名
硬编码成 zcbot_kernel.exe / zcbot_adapter.exe（未做平台判断）。在 Linux 上
把这两个文件放到对应目录后，launcher 会直接找到并跳过重编译。Linux 上带
.exe 的 ELF 二进制照常可执行（chmod +x 后 ./xxx.exe 即可）。

放置方式（二选一）：
  A. 把本 zip 解压到 framework/iipc/ 根目录，自动对齐覆盖：
       unzip iipc_linux_amd64.zip -d <仓库>/framework/iipc/
  B. 手动拷贝：
       zcbot_kernel.exe                          -> framework/iipc/go_kernel/
       zcbot_adapter.exe                         -> framework/iipc/rust_adapter/target/release/

前置：Python 侧（launcher.py / py_sdk / plugins）是源码，不编译。从 git 拉
取对应版本即可：
       git checkout v1.8.9-beta.1
    或直接用已发布仓库的 framework/iipc/ 目录（本产物只替换其中两个二进制）。

启动（在仓库根目录）：
       python main.py --iipc
    或 python -m framework.iipc

已知跨平台坑（非本产物问题）：若在 Linux 上让框架自己 cargo build，Rust 会
产出无扩展名的 zcbot_adapter，而 launcher 仍去找 zcbot_adapter.exe —— 会找不到、
Rust 协议端起不来（降级：事件注入可用、send 不可用）。用本预编译产物即可规避；
若要框架自编译可用，需把 launcher 的 .exe 硬编码改为按平台选扩展名（可让 AI 修）。
